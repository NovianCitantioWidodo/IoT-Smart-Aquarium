<?php 
$conn = mysqli_connect('localhost', 'karyasa2_iot', 'hidroponikroot', 'karyasa2_app');
if (mysqli_connect_error()) {
	echo 'Koneksi gagal dilakukan';
}
 ?>